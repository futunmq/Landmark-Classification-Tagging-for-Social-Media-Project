import torch
import torch.nn as nn


# define the CNN architecture
class MyModel(nn.Module):
    def __init__(self, num_classes: int = 1000, dropout: float = 0.7) -> None:

        super().__init__()

        # YOUR CODE HERE
        # Define a CNN architecture. Remember to use the variable num_classes
        # to size appropriately the output of your classifier, and if you use
        # the Dropout layer, use the variable "dropout" to indicate how much
        # to use (like nn.Dropout(p=dropout))
        
        self.model = nn.Sequential(
            # First convolutional layer: Input channels: 3 (RGB images) Output channels: 8 Kernel size: 3x3 Padding: 1
            nn.Conv2d(3, 8, kernel_size=3, padding=1),
            # Batch normalization on the output of the first convolution
            nn.BatchNorm2d(8),
            # Max pooling with a 2x2 kernel and stride 2
            nn.MaxPool2d(2, 2),
            # ReLU activation function
            nn.ReLU(),
            
            # Second convolutional layer: Input channels: 8 (from previous layer) Output channels: 16 Kernel size: 3x3 Padding: 1
            nn.Conv2d(8, 16, kernel_size=3, padding=1),
            # Batch normalization on the output of the second convolution
            nn.BatchNorm2d(16),
            # Max pooling with a 2x2 kernel and stride 2
            nn.MaxPool2d(2, 2),
            # ReLU activation function
            nn.ReLU(),
            
            # Third convolutional layer: Input channels: 16 (from previous layer) Output channels: 32 Kernel size: 3x3 Padding: 1
            nn.Conv2d(16, 32, kernel_size=3, padding=1),
            # Batch normalization on the output of the third convolution
            nn.BatchNorm2d(32),
            # Max pooling with a 2x2 kernel and stride 2
            nn.MaxPool2d(2, 2),
            # ReLU activation function
            nn.ReLU(),    
            
            # Flatten the output to a 1D tensor
            nn.Flatten(),
            
            # First fully connected layer: Input features: 25088 ((224*224)/2) Output features: 256
            nn.Linear(25088, out_features=256),
            # Batch normalization on the output of the first linear layer
            nn.BatchNorm1d(256),
            # Dropout regularization
            nn.Dropout(dropout),
            # ReLU activation function
            nn.ReLU(),
            
            # Output layer: Input features: 256 (from previous layer) Output features: num_classes
            nn.Linear(256, num_classes)
        )        

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # YOUR CODE HERE: process the input tensor through the
        # feature extractor, the pooling and the final linear
        # layers (if appropriate for the architecture chosen)
        
        x =  self.model(x)        
        return x


######################################################################################
#                                     TESTS
######################################################################################
import pytest


@pytest.fixture(scope="session")
def data_loaders():
    from .data import get_data_loaders

    return get_data_loaders(batch_size=2)


def test_model_construction(data_loaders):

    model = MyModel(num_classes=23, dropout=0.3)

    dataiter = iter(data_loaders["train"])
    images, labels = dataiter.next()

    out = model(images)

    assert isinstance(
        out, torch.Tensor
    ), "The output of the .forward method should be a Tensor of size ([batch_size], [n_classes])"

    assert out.shape == torch.Size(
        [2, 23]
    ), f"Expected an output tensor of size (2, 23), got {out.shape}"
